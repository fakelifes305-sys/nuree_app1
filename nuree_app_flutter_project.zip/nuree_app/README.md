# Nuree App

Flutter mobile wallet frontend/demo.

## Build
flutter pub get
flutter analyze
flutter test
flutter build apk --release

## GitHub Actions
Push to `main`, then open GitHub → Actions → Build Nuree APK.
The workflow builds and uploads the release APK as an artifact.
