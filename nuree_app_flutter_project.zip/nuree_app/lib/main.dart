import 'package:flutter/material.dart';

void main() => runApp(const NureeApp());

class NureeApp extends StatelessWidget {
  const NureeApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Nuree',
    theme: ThemeData(useMaterial3: true,
      colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF16803C))),
    home: const LoginPage(),
  );
}

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});
  @override State<LoginPage> createState() => _LoginPageState();
}
class _LoginPageState extends State<LoginPage> {
  final phone = TextEditingController(), pin = TextEditingController();
  void login() {
    if (phone.text.trim().isEmpty || pin.text.length < 4) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Enter phone number and PIN')));
      return;
    }
    Navigator.pushReplacement(context,
      MaterialPageRoute(builder: (_) => const HomePage()));
  }
  @override Widget build(BuildContext context) => Scaffold(
    backgroundColor: const Color(0xFF16803C),
    body: SafeArea(child: Center(child: SingleChildScrollView(
      padding: const EdgeInsets.all(24),
      child: Card(child: Padding(padding: const EdgeInsets.all(24),
        child: Column(children: [
          const CircleAvatar(radius: 42, backgroundColor: Color(0xFF16803C),
            child: Icon(Icons.account_balance_wallet, color: Colors.white, size: 42)),
          const SizedBox(height: 20),
          const Text('Nuree', style: TextStyle(fontSize: 30, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const Text('Your simple mobile wallet', style: TextStyle(color: Colors.grey)),
          const SizedBox(height: 30),
          TextField(controller: phone, keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Phone number',
              prefixIcon: Icon(Icons.phone), border: OutlineInputBorder())),
          const SizedBox(height: 16),
          TextField(controller: pin, obscureText: true, keyboardType: TextInputType.number,
            maxLength: 6, decoration: const InputDecoration(labelText: 'PIN',
              prefixIcon: Icon(Icons.lock), border: OutlineInputBorder(), counterText: '')),
          const SizedBox(height: 20),
          SizedBox(width: double.infinity, height: 52,
            child: ElevatedButton(onPressed: login, child: const Text('Login'))),
          TextButton(onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Account creation will be added later.'))),
            child: const Text('Create new account')),
        ]))))));
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  int index = 0;
  final pages = const [DashboardPage(), TransactionsPage(), ServicesPage(), AccountPage()];
  @override Widget build(BuildContext context) => Scaffold(
    body: pages[index],
    bottomNavigationBar: NavigationBar(selectedIndex: index,
      onDestinationSelected: (i) => setState(() => index = i),
      destinations: const [
        NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
        NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Transactions'),
        NavigationDestination(icon: Icon(Icons.apps_outlined), selectedIcon: Icon(Icons.apps), label: 'Services'),
        NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'Account'),
      ]),
  );
}

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});
  void pin(BuildContext c, String action) => Navigator.push(c,
    MaterialPageRoute(builder: (_) => PinPage(action: action)));
  @override Widget build(BuildContext context) => SafeArea(child: SingleChildScrollView(
    padding: const EdgeInsets.all(18), child: Column(crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Row(children: [
        const CircleAvatar(child: Icon(Icons.person)), const SizedBox(width: 12),
        const Expanded(child: Text('Selam, Nuredin', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none)),
      ]),
      const SizedBox(height: 22),
      Container(width: double.infinity, padding: const EdgeInsets.all(22),
        decoration: BoxDecoration(color: const Color(0xFF16803C), borderRadius: BorderRadius.circular(24)),
        child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('Available Balance', style: TextStyle(color: Colors.white70)),
          SizedBox(height: 8), Text('ETB 48.98', style: TextStyle(color: Colors.white, fontSize: 32, fontWeight: FontWeight.bold)),
          SizedBox(height: 8), Text('Demo balance', style: TextStyle(color: Colors.white70)),
        ])),
      const SizedBox(height: 24),
      const Text('Quick Actions', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const SizedBox(height: 14),
      GridView.count(shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
        crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.5,
        children: [
          ActionCard(icon: Icons.send, title: 'Send Money', onTap: () => pin(context, 'Send Money')),
          ActionCard(icon: Icons.add_circle, title: 'Cash In', onTap: () => pin(context, 'Cash In')),
          ActionCard(icon: Icons.account_balance, title: 'Transfer to Bank', onTap: () => pin(context, 'Transfer to Bank')),
          ActionCard(icon: Icons.phone_android, title: 'Airtime', onTap: () => pin(context, 'Airtime')),
        ]),
      const SizedBox(height: 25),
      const Text('Recent Activity', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      const TransactionTile(icon: Icons.arrow_downward, title: 'Money Received', amount: '+ ETB 300.00', date: '12 Sep 2026'),
      const TransactionTile(icon: Icons.arrow_upward, title: 'Payment', amount: '- ETB 50.00', date: '11 Sep 2026'),
    ])));
}

class PinPage extends StatefulWidget {
  final String action;
  const PinPage({super.key, required this.action});
  @override State<PinPage> createState() => _PinPageState();
}
class _PinPageState extends State<PinPage> {
  String pin = '';
  void add(String n) {
    if (pin.length < 6) setState(() => pin += n);
    if (pin.length == 6) Future.delayed(const Duration(milliseconds: 250), () {
      if (mounted) Navigator.pushReplacement(context,
        MaterialPageRoute(builder: (_) => SuccessPage(action: widget.action)));
    });
  }
  Widget key(String n) => Expanded(child: Padding(padding: const EdgeInsets.all(6),
    child: ElevatedButton(onPressed: () => add(n), child: Text(n, style: const TextStyle(fontSize: 24)))));
  @override Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.action)),
    body: SafeArea(child: Column(children: [
      const SizedBox(height: 40),
      const Text('Enter PIN', style: TextStyle(fontSize: 26, fontWeight: FontWeight.bold)),
      const SizedBox(height: 20),
      Row(mainAxisAlignment: MainAxisAlignment.center,
        children: List.generate(6, (i) => Container(margin: const EdgeInsets.all(6), width: 15, height: 15,
          decoration: BoxDecoration(shape: BoxShape.circle,
            color: i < pin.length ? Colors.green : Colors.grey.shade300)))),
      const Spacer(),
      Row(children: [key('1'), key('2'), key('3')]),
      Row(children: [key('4'), key('5'), key('6')]),
      Row(children: [key('7'), key('8'), key('9')]),
      Row(children: [
        const Spacer(), key('0'),
        Expanded(child: Padding(padding: const EdgeInsets.all(6),
          child: ElevatedButton(onPressed: () {
            if (pin.isNotEmpty) setState(() => pin = pin.substring(0, pin.length - 1));
          }, child: const Icon(Icons.backspace)))),
      ]),
      const SizedBox(height: 20),
    ])));
}

class SuccessPage extends StatelessWidget {
  final String action;
  const SuccessPage({super.key, required this.action});
  @override Widget build(BuildContext context) => Scaffold(body: Center(
    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      const Icon(Icons.check_circle, color: Colors.green, size: 90),
      const SizedBox(height: 20),
      const Text('Successful', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      const SizedBox(height: 10), Text('$action completed successfully.'),
      const SizedBox(height: 30),
      ElevatedButton(onPressed: () => Navigator.pop(context), child: const Text('Done')),
    ])));
}

class TransactionsPage extends StatelessWidget {
  const TransactionsPage({super.key});
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18),
    children: const [
      Text('Transactions', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
      SizedBox(height: 20),
      TransactionTile(icon: Icons.arrow_downward, title: 'Money Received', amount: '+ ETB 300.00', date: '12 Sep 2026'),
      TransactionTile(icon: Icons.arrow_upward, title: 'Payment', amount: '- ETB 50.00', date: '11 Sep 2026'),
      TransactionTile(icon: Icons.phone, title: 'Airtime', amount: '- ETB 20.00', date: '10 Sep 2026'),
    ]));
}

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});
  @override Widget build(BuildContext context) {
    final services = [['Send Money', Icons.send], ['Cash In/Out', Icons.account_balance_wallet],
      ['Airtime', Icons.phone_android], ['Bank Transfer', Icons.account_balance],
      ['QR Payment', Icons.qr_code], ['Bills', Icons.receipt_long]];
    return SafeArea(child: Padding(padding: const EdgeInsets.all(18), child: Column(
      crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('Services', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
        const SizedBox(height: 20),
        Expanded(child: GridView.builder(itemCount: services.length,
          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2, crossAxisSpacing: 12, mainAxisSpacing: 12),
          itemBuilder: (_, i) => ActionCard(icon: services[i][1] as IconData, title: services[i][0] as String, onTap: () {}))),
      ])));
  }
}

class AccountPage extends StatelessWidget {
  const AccountPage({super.key});
  @override Widget build(BuildContext context) => SafeArea(child: ListView(padding: const EdgeInsets.all(18), children: [
    const Text('Account', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
    const SizedBox(height: 25),
    const ListTile(leading: CircleAvatar(child: Icon(Icons.person)), title: Text('Nuredin'), subtitle: Text('+251 900 000 000')),
    const Divider(),
    ListTile(leading: const Icon(Icons.lock), title: const Text('Change PIN'), onTap: () {}),
    ListTile(leading: const Icon(Icons.notifications), title: const Text('Notifications'), onTap: () {}),
    ListTile(leading: const Icon(Icons.security), title: const Text('Security'), onTap: () {}),
    ListTile(leading: const Icon(Icons.logout), title: const Text('Logout'), onTap: () {
      Navigator.pushAndRemoveUntil(context, MaterialPageRoute(builder: (_) => const LoginPage()), (_) => false);
    }),
  ]));
}

class ActionCard extends StatelessWidget {
  final IconData icon; final String title; final VoidCallback onTap;
  const ActionCard({super.key, required this.icon, required this.title, required this.onTap});
  @override Widget build(BuildContext context) => Card(child: InkWell(
    borderRadius: BorderRadius.circular(15), onTap: onTap,
    child: Padding(padding: const EdgeInsets.all(15), child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, size: 35, color: Colors.green), const SizedBox(height: 10),
      Text(title, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600)),
    ])));
}

class TransactionTile extends StatelessWidget {
  final IconData icon; final String title, amount, date;
  const TransactionTile({super.key, required this.icon, required this.title, required this.amount, required this.date});
  @override Widget build(BuildContext context) => Card(child: ListTile(
    leading: CircleAvatar(child: Icon(icon)), title: Text(title), subtitle: Text(date),
    trailing: Text(amount, style: TextStyle(fontWeight: FontWeight.bold,
      color: amount.startsWith('+') ? Colors.green : Colors.red))));
}
