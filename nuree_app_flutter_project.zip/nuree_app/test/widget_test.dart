import 'package:flutter_test/flutter_test.dart';
import 'package:nuree_app/main.dart';

void main() {
  testWidgets('Nuree login page loads', (tester) async {
    await tester.pumpWidget(const NureeApp());
    expect(find.text('Nuree'), findsOneWidget);
    expect(find.text('Login'), findsOneWidget);
  });
}
